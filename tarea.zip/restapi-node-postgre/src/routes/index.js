const {Router} = require('express');
const router = Router();

const { getAutor, createAutor, getAutorbyId, eliminarAutor, updateAutor, getLibro, getLibrobyId, createLibro, updateLibro, eliminarLibro} = require('../controllers/index.controllers')

//Autores
router.get('/autores', getAutor);
router.get('/autores/:id', getAutorbyId);
router.post('/autores', createAutor);
router.put('/autores/:id', updateAutor);
router.delete('/autores/:id', eliminarAutor);

//Libros
router.get('/libros', getLibro);
router.get('/libros/:id', getLibrobyId);
router.post('/libros', createLibro);
router.put('/libros/:id', updateLibro);
router.delete('/libros/:id', eliminarLibro);

module.exports = router; 