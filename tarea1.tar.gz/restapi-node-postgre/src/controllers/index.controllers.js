const {Pool} = require('pg');

const pool = new Pool ({
    host: 'localhost',
    user: 'postgres',
    password: 'root',
    database: 'tarea1',
    port: '5432'
});

//Autores

const getAutor = async (req, res) => 
{const respuesta = await pool.query('SELECT * FROM autores');
console.log(respuesta.rows);
res.status(200).json(respuesta.rows);
}


const getAutorbyId = async (req, res) => {
    const id = req.params.id;
    const respuesta = await pool.query('select * from autores where idautor = $1', [id]);
    res.json(respuesta.rows);
}

  
const createAutor = async (req, res) => {
    const {idautor, nombre, apellido, direccion, telefono, correo} = req.body;

    const respuesta = await pool.query('insert into autores (idautor, nombre, apellido, direccion, telefono, correo) values ($1, $2, $3, $4, $5, $6)', [idautor, nombre, apellido, direccion, telefono, correo]);
    console.log(respuesta);
    res.json({
        message: 'Autor agregado exitosamente',
        body: {
            user: {idautor, nombre, apellido, direccion, telefono, correo}
        }
    })
};

const updateAutor = async (req, res) => {
    const id = req.params.id;
    const {nombre, apellido, direccion, telefono, correo} = req.body;
    const respuesta = await pool.query('update autores set nombre = $1, apellido = $2, direccion = $3, telefono = $4, correo = $5 where idautor = $6', [
        nombre,
        apellido,
        direccion,
        telefono,
        correo,
        id
    ]);
    console.log(respuesta);
    res.json('Autor actualizado exitosamente');
};

const eliminarAutor = async (req, res) =>{
    const id = req.params.id;
    const respuesta = await pool.query('delete from autores where idautor = $1', [id]);
    console.log(respuesta);
    res.json(`Autor ${id} eliminado exitosamente`);
};

//Libros

const getLibro = async (req, res) => {
    const respuesta = await pool.query('SELECT * FROM libros');
    console.log(respuesta.rows);
    res.status(200).json(respuesta.rows);
}

const getLibrobyId = async (req, res) => {
    const id = req.params.id;
    const respuesta = await pool.query('select * from libros where idlibro = $1', [id]);
    res.json(respuesta.rows);
}

const createLibro = async (req, res) => {
    const {titulo, idautor, isbn, paginas, edicion} = req.body;

    const respuesta = await pool.query('insert into libros (titulo, idautor, isbn, paginas, edicion) values ($1, $2, $3, $4, $5)', [titulo, idautor, isbn, paginas, edicion]);
    console.log(respuesta);
    res.json({
        message: 'Libro agregado exitosamente',
        body: {
            libro: {titulo, idautor, isbn, paginas, edicion}
        }
    })
};

const updateLibro = async (req, res) => {
    const id = req.params.id;
    const {titulo, idautor, isbn, paginas, edicion} = req.body;
    const respuesta = await pool.query('update libros set titulo = $1, idautor = $2, isbn = $3, paginas = $4, edicion = $5 where idlibro = $6', [
        titulo, 
        idautor, 
        isbn, 
        paginas, 
        edicion,
        id
    ]);
    console.log(respuesta);
    res.json('Libro actualizado exitosamente');
};

const eliminarLibro = async (req, res) =>{
    const id = req.params.id;
    const respuesta = await pool.query('delete from libros where idlibro = $1', [id]);
    console.log(respuesta);
    res.json(`Libro ${id} eliminado exitosamente`);
};

module.exports = {
    getAutor,
    getAutorbyId,
    createAutor,
    updateAutor,
    eliminarAutor,
    getLibro,
    getLibrobyId,
    createLibro,
    updateLibro,
    eliminarLibro
}